﻿namespace JJ.Presentation.QuestionAndAnswer.Mvc.Helpers
{
	public interface IAppSettings
	{
		bool QuestionAndAnswer_ShowUnfinishedFeatures { get; }
	}
}