#ifndef _TRAMPOLINE_UI_VIDEOVIEWCONTROLLER_H_
#define _TRAMPOLINE_UI_VIDEOVIEWCONTROLLER_H_

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>
#include "iPhone_Common.h"


@interface UnityVideoViewController : MPMoviePlayerViewController {}
+ (void)Initialize;
@end

#endif // _TRAMPOLINE_UI_VIDEOVIEWCONTROLLER_H_
