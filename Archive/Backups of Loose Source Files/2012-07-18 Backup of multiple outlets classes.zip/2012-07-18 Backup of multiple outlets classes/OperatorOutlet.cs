﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Circle.OS.Data.Collections;

namespace Circle.AppsAndMedia.Sound
{
    public class OperatorOutlet<TOperator> : OperatorInOrOutlet<TOperator>
    {
        public OperatorOutlet(TOperator op, string name)
            : base(op, name)
        { }

        public virtual double Value(double time)
        {
            throw new NotImplementedException();
        }
    }
}
