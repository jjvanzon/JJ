﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Circle.OS.Data.Collections;

namespace Circle.AppsAndMedia.Sound
{
    public class OperatorOutlets<TOperator, TInlet, TOutlet> : OperatorInOrOutlets<TOperator, TOutlet, TInlet, TOutlet>
        where TOutlet : OperatorInOrOutlet<TOperator>
    { }
}
