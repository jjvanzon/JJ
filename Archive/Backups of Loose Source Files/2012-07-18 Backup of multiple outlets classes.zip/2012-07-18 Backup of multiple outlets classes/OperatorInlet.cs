﻿//
//  Circle.AppsAndMedia.Sound.OperatorInlet
//
//      Author: Jan-Joost van Zon
//      Date: 2012-07-16 - 2012-07-16
//
//  -----

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Circle.Framework.Code.Conditions;
using Circle.Framework.Code.Events;
using System.Diagnostics;

namespace Circle.AppsAndMedia.Sound
{
    public class OperatorInlet<TOperator> : OperatorInOrOutlet<TOperator>
    {
        public OperatorInlet(TOperator op, string name)
            : base(op, name)
        { }

        public OperatorOutlet<TOperator> Operand;
    }
}
