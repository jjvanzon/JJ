﻿//
//  Circle.AppsAndMedia.Sound.Operator
//
//      Author: Jan-Joost van Zon
//      Date: 2011-10-20 - 2012-07-16
//
//  -----

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using Circle.OS.Data.Collections;
using Circle.Framework.Data.Concepts;
using Circle.Framework.Code.Relations;
using Circle.Framework.Code.Conditions;
using Circle.Framework.Code.Events;

namespace Circle.AppsAndMedia.Sound
{
    [DebuggerDisplay("{Name}, Outlet[0].Result(time: 0) = {Outlet[0].Result(0)} {GetType().FullName}")]
    public class Operator_New<TInlet, TOutlet> : IName, IWarningProvider
        where TInlet : OperatorInOrOutlet<Operator_New<TInlet, TOutlet>>
        where TOutlet : OperatorInOrOutlet<Operator_New<TInlet, TOutlet>>
    {
        // Constructor

        public Operator_New()
        {
            InitializePatch();
            InitializeName();
            InitializeWarningProviderBase();
        }

        // Inlets

        public OperatorInlets<Operator_New<TInlet, TOutlet>, TInlet, TOutlet> Inlets { get; protected set; }

        // Outlets

        public OperatorOutlets<Operator_New<TInlet, TOutlet>, TInlet, TOutlet> Outlets { get; protected set; }

        // Time

        public double Time;

        // Name

        public string Name
        {
            [DebuggerHidden] get { return NameEvents.Value; }
            [DebuggerHidden] set { NameEvents.Value = value; }
        }

        public Events<string> NameEvents { get; private set; }

        private void InitializeName()
        {
            NameEvents = new Events<string>(this, "Name");

            NameEvents.Changing += (s, e) =>
            {
                Condition.NotInteger(e.Value, NameEvents.Name);
            };
        }

        // Patch

        public ManyToOne<Patch> PatchEvents { get; private set; }

        public Patch Patch
        {
            [DebuggerHidden] get { return PatchEvents.Value; }
            [DebuggerHidden] set { PatchEvents.Value = value; }
        }

        private void InitializePatch()
        {
            PatchEvents = new ManyToOne<Patch>
            (
                this, "Patch",
                add: p => p.Operators.Add(this),
                remove: p => p.Operators.Remove(this),
                contains: p => p.Operators.Contains(this)
            );
        }

        // Warnings

        public readonly WarningProviderBase WarningProviderBase = new WarningProviderBase();

        private void InitializeWarningProviderBase()
        {
            WarningProviderBase.AdditionalWarningProvidersRequested = () => Inlets;
        }
        
        public List<string> GetWarnings(HashSet<IWarningProvider> alreadyDone)
        {
            return WarningProviderBase.GetWarnings(alreadyDone);
        }
    }
}
