﻿//
//  Circle.AppsAndMedia.Sound.OperatorOutlets
//
//      Author: Jan-Joost van Zon
//      Date: 2012-07-16 - 2012-07-16
//
//  -----

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Circle.Framework.Code.Conditions;
using Circle.OS.Data.Collections;
using Circle.Framework.Data.Concepts;

namespace Circle.AppsAndMedia.Sound
{
    public class OperatorInOrOutlets<TOperator, TInOrOutlet, TInlet, TOutlet>
        where TInOrOutlet : OperatorInOrOutlet<TOperator>
    {
        // Constructor

        public OperatorInOrOutlets()
        {
            InitializeIndexerByName();
        }

        // List

        protected readonly ListWithEvents<TInOrOutlet> List = new ListWithEvents<TInOrOutlet>();

        // Indexer by Number

        public TInOrOutlet this[int index]
        {
            get { return List[index]; }
        }

        // Indexer by Name

        public TInOrOutlet this[string name]
        {
            get
            {
                return List.Where(x => x.Name == name).Single();
            }
        }

        //private UniqueConstraintByKey<TInOrOutlet> NameUnique;

        private void InitializeIndexerByName()
        {
            //NameUnique = new UniqueConstraintByKey<TInOrOutlet>(List, x => x.NameEvents, "Name");
        }
    }
}
