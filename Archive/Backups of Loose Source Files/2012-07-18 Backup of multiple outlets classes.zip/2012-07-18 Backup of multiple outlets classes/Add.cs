﻿//
//  Circle.AppsAndMedia.Sound.Add
//
//      Author: Jan-Joost van Zon
//      Date: 2011-10-20 - 2011-10-20
//
//  -----

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using Circle.AppsAndMedia.Sound.Properties;
using Circle.OS.Data.Collections;

namespace Circle.AppsAndMedia.Sound
{
    public class Add : Operator_New<OperatorInlet<Add>, Add.AddOutlet>
    {
        public Add()
        {
            InitializeInlets();
            InitializeOutlets();
            InitializeWarningProviderBase();
        }

        // Inlets

        private const string OPERAND_A_NAME = "OperandA";
        private const string OPERAND_B_NAME = "OperandB";

        public OperatorOutlet<Add> OperandA
        {
            get { return Inlets[OPERAND_A_NAME].Operand; }
            set { Inlets[OPERAND_A_NAME].Operand = value; }
        }

        public OperatorOutlet<Add> OperandB
        {
            get { return Inlets[OPERAND_B_NAME].Operand; }
            set { Inlets[OPERAND_B_NAME].Operand = value; }
        }

        public new AddInlets Inlets { get; private set; }

        private void InitializeInlets()
        {
            Inlets = new AddInlets(this);
        }

        public class AddInlets : OperatorInlets<Add, OperatorInlet<Add>, AddOutlet>
        {
            internal AddInlets(Add op)
            {
                List.Add(new OperatorInlet<Add>(op, OPERAND_A_NAME));
                List.Add(new OperatorInlet<Add>(op, OPERAND_B_NAME));
            }
        }

        // Outlet

        private const string RESULT_NAME = "Result";

        public AddOutlet Result
        {
            get { return this.Outlets[RESULT_NAME]; }
        }

        public new AddOutlets Outlets { get; private set; }

        private void InitializeOutlets()
        {
            Outlets = new AddOutlets(this);
        }

        public class AddOutlets : OperatorOutlets<Add, OperatorInlet<Add>, AddOutlet>
        {
            internal AddOutlets(Add op)
            {
                List.Add(new AddOutlet(op));
            }
        }

        public class AddOutlet : OperatorOutlet<Add>
        {
            internal AddOutlet(Add op)
                : base(op, RESULT_NAME)
            { }

            public override double Value(double time)
            {
                if (Operator.OperandA == null || Operator.OperandB == null) return 0;
                return Operator.OperandA.Value(time) + Operator.OperandB.Value(time);
            }
        }

        // Warnings

        private void InitializeWarningProviderBase()
        {
            WarningProviderBase.AddWarningsRequested += WarningProviderBase_AddWarningsRequested;
        }

        private void WarningProviderBase_AddWarningsRequested(object sender, WarningProviderBase.AddWarningsRequestedEventArgs e)
        {
            if (OperandA == null)
            {
                e.List.Add(String.Format(Resources.OperatorPropertyNotSet, GetType().Name, Name, "OperandA"));
            }

            if (OperandB == null)
            {
                e.List.Add(String.Format(Resources.OperatorPropertyNotSet, GetType().Name, Name, "OperandB"));
            }
        }
    }
}
