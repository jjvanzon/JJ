﻿//
//  Circle.AppsAndMedia.Sound.OperatorOutlet
//
//      Author: Jan-Joost van Zon
//      Date: 2012-07-16 - 2012-07-16
//
//  -----

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Circle.Framework.Code.Conditions;
using Circle.Framework.Code.Events;

namespace Circle.AppsAndMedia.Sound
{
    public class OperatorInOrOutlet<TOperator>
    {
        // Constructor

        public OperatorInOrOutlet()
        { 
            // Required for use as an item type in a unique constraint.
        }

        public OperatorInOrOutlet(TOperator op, string name)
        {
            InitializeOperator(op);
            InitializeName(name);
        }

        // Operator

        public TOperator Operator { get; private set; }

        private void InitializeOperator(TOperator op)
        {
            Condition.NotNull(op, "Operator");
            Operator = op;
        }

        // Name

        public string Name 
        {
            get { return NameEvents.Value; }
            private set { NameEvents.Value = value; }
        }

        public Events<string> NameEvents { get; private set; }

        public void InitializeName(string name)
        {
            NameEvents = new Events<string>(this, "Name");
            Name = name;
        }
    }
}
