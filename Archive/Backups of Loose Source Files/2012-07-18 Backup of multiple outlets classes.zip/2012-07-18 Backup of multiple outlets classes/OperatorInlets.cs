﻿//
//  Circle.AppsAndMedia.Sound.OperatorInlets
//
//      Author: Jan-Joost van Zon
//      Date: 2012-07-16 - 2012-07-16
//
//  -----

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Circle.Framework.Code.Conditions;
using Circle.OS.Data.Collections;
using Circle.Framework.Data.Concepts;

namespace Circle.AppsAndMedia.Sound
{
    public class OperatorInlets<TOperator, TInlet, TOutlet> : OperatorInOrOutlets<TOperator, TInlet, TInlet, TOutlet>
        where TInlet : OperatorInOrOutlet<TOperator>
    { }
}
