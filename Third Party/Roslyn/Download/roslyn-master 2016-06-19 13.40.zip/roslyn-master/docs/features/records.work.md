Records Work Items
==================

This is the TODO list for the development of the records language feature for C# 7.

- [ ] This checklist needs to be written
- [ ] The feature needs to be implemented
- [ ] The feature needs to be tested
