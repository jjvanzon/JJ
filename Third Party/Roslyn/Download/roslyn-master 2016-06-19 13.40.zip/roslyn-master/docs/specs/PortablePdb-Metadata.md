#Portable PDB v1.0: Format Specification

Moved to 
https://github.com/dotnet/corefx/blob/master/src/System.Reflection.Metadata/specs/PortablePdb-Metadata.md
