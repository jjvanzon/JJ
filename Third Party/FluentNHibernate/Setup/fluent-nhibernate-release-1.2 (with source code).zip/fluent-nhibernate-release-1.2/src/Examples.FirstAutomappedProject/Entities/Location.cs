﻿namespace Examples.FirstAutomappedProject.Entities
{
    public class Location
    {
        public virtual int Aisle { get; set; }
        public virtual int Shelf { get; set; }
    }
}