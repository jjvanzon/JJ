using System.Security;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyCompany("http://fluentnhibernate.org")]
[assembly: AssemblyProduct("FluentNHibernate")]
[assembly: AssemblyCopyright("Copyright 2008-2010 James Gregory and contributors (Paul Batum, Hudson Akridge et al). All rights reserved.")]
[assembly: AssemblyVersion("1.2.0.0")]

[assembly: AllowPartiallyTrustedCallers()]

