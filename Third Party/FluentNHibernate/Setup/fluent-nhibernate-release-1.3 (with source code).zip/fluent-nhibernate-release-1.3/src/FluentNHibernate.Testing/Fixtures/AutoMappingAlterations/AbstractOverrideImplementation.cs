﻿using FluentNHibernate.Testing.Fixtures.AutoMappingAlterations.Model;

namespace FluentNHibernate.Testing.Fixtures.AutoMappingAlterations
{
	public class AbstractOverrideImplementation : AbstractOveride<Qux>
	{

	}
}
