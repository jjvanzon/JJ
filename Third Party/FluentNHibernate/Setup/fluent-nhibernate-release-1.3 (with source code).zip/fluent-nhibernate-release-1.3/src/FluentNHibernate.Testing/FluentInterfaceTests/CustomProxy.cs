namespace FluentNHibernate.Testing.FluentInterfaceTests
{
    internal class CustomProxy
    {}

    internal class SecondCustomProxy : CustomProxy
    {}
}