﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FluentNHibernate.Specs.FluentInterface.Fixtures
{
    class SuperTarget
    {
    }

    class ChildTarget : SuperTarget
    {}
}
