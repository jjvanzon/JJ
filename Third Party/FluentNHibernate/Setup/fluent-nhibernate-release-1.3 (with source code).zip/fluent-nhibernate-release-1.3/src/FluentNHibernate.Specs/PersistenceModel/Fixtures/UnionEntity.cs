﻿namespace FluentNHibernate.Specs.PersistenceModel.Fixtures
{
    class UnionEntity
    {
        public int Id { get; set; }
    }
}