namespace NHibernate.Cfg.MappingSchema
{
	public interface IReferencePropertyMapping
	{
		string Cascade { get; }
	}
}