namespace NHibernate.Cfg.MappingSchema
{
	public interface ITypeMapping
	{
		HbmType Type { get; }
	}
}